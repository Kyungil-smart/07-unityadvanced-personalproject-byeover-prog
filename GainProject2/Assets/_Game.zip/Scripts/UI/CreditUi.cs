using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public sealed class CreditUI : MonoBehaviour
{
    [Header("참조")]
    [SerializeField] private RectTransform creditContent;
    [SerializeField] private TMP_Text creditText;

    [Header("설정")]
    [SerializeField] private float scrollSpeed = 50f;
    [SerializeField] private float startDelay = 1f;
    [SerializeField] private string returnSceneName = "MainMenu";

    [Header("크레딧 내용")]
    [SerializeField, TextArea(10, 30)] private string creditString =
        "그날이후\n\n\n" +
        "개발\n(이름)\n\n" +
        "기획\n(이름)\n\n" +
        "아트\n(이름)\n\n" +
        "음악\n(이름)\n\n" +
        "프로그래밍\n(이름)\n\n\n" +
        "감사합니다!";

    private float elapsed;
    private bool started;
    private float startY;

    private void Start()
    {
        if (creditText != null)
            creditText.text = creditString;

        if (creditContent != null)
        {
            startY = creditContent.anchoredPosition.y;
            // 화면 아래에서 시작
            creditContent.anchoredPosition = new Vector2(
                creditContent.anchoredPosition.x,
                startY - Screen.height
            );
        }
    }

    private void Update()
    {
        elapsed += Time.unscaledDeltaTime;

        if (elapsed < startDelay) return;
        started = true;

        // 스크롤
        if (creditContent != null)
        {
            var pos = creditContent.anchoredPosition;
            pos.y += scrollSpeed * Time.unscaledDeltaTime;
            creditContent.anchoredPosition = pos;
        }
        
        if (Input.anyKeyDown)
        {
            ReturnToMenu();
        }
    }

    private void ReturnToMenu()
    {
        Time.timeScale = 1f;

        if (!string.IsNullOrWhiteSpace(returnSceneName))
            SceneManager.LoadScene(returnSceneName);
    }
}